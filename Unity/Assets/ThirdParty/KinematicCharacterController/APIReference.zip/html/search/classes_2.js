var searchData=
[
  ['icharactercontroller',['ICharacterController',['../interface_kinematic_character_controller_1_1_i_character_controller.html',1,'KinematicCharacterController']]],
  ['imovercontroller',['IMoverController',['../interface_kinematic_character_controller_1_1_i_mover_controller.html',1,'KinematicCharacterController']]]
];
